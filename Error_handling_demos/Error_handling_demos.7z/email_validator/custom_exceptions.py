class MustContainAtSymbolError(Exception):
    pass

class NameToShortNameError(Exception):
    pass

class InvalidDomainError(Exception):
    pass
